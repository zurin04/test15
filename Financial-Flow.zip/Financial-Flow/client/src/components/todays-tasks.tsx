import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

export default function TodaysTasks() {
  const today = format(new Date(), "yyyy-MM-dd");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: todayTasks, isLoading } = useQuery({
    queryKey: ["/api/tasks", { date: today }],
    queryFn: () => fetch(`/api/tasks?date=${today}`).then(res => res.json()),
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => 
      apiRequest("PUT", `/api/tasks/${id}`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({ title: "Task updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update task", variant: "destructive" });
    },
  });

  const toggleTaskComplete = (task: any) => {
    const newStatus = task.status === "completed" ? "to-do" : "completed";
    updateTaskMutation.mutate({ id: task.id, status: newStatus });
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge className="bg-error-light text-error">High</Badge>;
      case "medium":
        return <Badge className="bg-warning-light text-warning">Medium</Badge>;
      case "low":
        return <Badge className="bg-gray-100 text-gray-700">Low</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-700">{priority}</Badge>;
    }
  };

  const pendingCount = todayTasks?.filter((task: any) => task.status !== "completed").length || 0;

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-12 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Today's Tasks</h2>
          <Badge className="bg-primary-light text-primary text-xs">
            {pendingCount} pending
          </Badge>
        </div>
      </div>
      <div className="p-4 sm:p-6 space-y-3">
        {todayTasks && todayTasks.length > 0 ? (
          todayTasks.map((task: any) => (
            <div key={task.id} className="flex items-center space-x-3 p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
              <Checkbox
                checked={task.status === "completed"}
                onCheckedChange={() => toggleTaskComplete(task)}
                disabled={updateTaskMutation.isPending}
              />
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium truncate ${task.status === "completed" ? 'text-gray-500 line-through' : 'text-gray-900'}`}>
                  {task.title}
                </p>
                <p className={`text-xs ${task.status === "completed" ? 'text-gray-400' : 'text-gray-500'}`}>
                  {task.category} • {task.priority} Priority
                </p>
              </div>
              <div className="flex-shrink-0">
                {task.status === "completed" ? (
                  <Badge className="bg-success-light text-success text-xs">Completed</Badge>
                ) : (
                  getPriorityBadge(task.priority)
                )}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center text-gray-500 py-8">
            No tasks scheduled for today
          </div>
        )}
      </div>
    </div>
  );
}
